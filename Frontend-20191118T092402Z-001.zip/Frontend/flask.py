#coding:utf-8

from flask import Flask

app = Flask(__name__)

@app.route('/index')
def index():
   return render_template('acceuil.html', title='F1 Online')

if __name__ == '__main__':
   app.run()
